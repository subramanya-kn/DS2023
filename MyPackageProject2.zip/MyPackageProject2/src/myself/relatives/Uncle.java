package myself.relatives;

import myself.Father;

public class Uncle {

	public void probing() {
		
		Father father = new Father();
		
		System.out.println("Show me your gold chain : "+father.goldChain);
		System.out.println("Show me your cars       : "+father.vehicles);
		System.out.println("How much pf : "+father.pf);
		System.out.println("Where are ur props : "+father.someProperty);
	}

}

class Child extends Father
{
	
}

