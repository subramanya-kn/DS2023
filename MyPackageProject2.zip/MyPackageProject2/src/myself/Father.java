package myself;

public class Father {

	          int goldChain=12; //inches
	private   int pf=35;//lakhs
	public    int vehicles=3; //3 cars // 
	protected int someProperty=2; // 2 bunglows
	
	void iKnowMyDetails() {
		System.out.println("gold chain : "+goldChain);
		System.out.println("pf         : "+pf);
		System.out.println("vehicles   : "+vehicles);
		System.out.println("some props : "+someProperty);
		
	}
	
}

