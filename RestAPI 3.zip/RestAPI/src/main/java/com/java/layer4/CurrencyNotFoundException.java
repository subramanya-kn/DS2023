package com.java.layer4;

public class CurrencyNotFoundException extends Exception {
	public CurrencyNotFoundException(String str) {
		super(str);
		
	}
}
