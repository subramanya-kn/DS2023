package com.java.layer4;

public class TargetCurrencyNotFoundException extends Exception {
	public TargetCurrencyNotFoundException(String str) {
		super(str);
		
	}
}
