package com.java.layer3;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class DAOImplTest {

	

	@Test
	public void testDrivenDevelopment()
	{
		System.out.println("Testing condition1");
		Assertions.assertTrue(100>15);
		System.out.println("condition1 passed");
		
		System.out.println("Testing condition2");
		Assertions.assertTrue(2>15);
		System.out.println("condition2 passed");
		
		System.out.println("Testing condition3");
		Assertions.assertTrue(30>15);
		System.out.println("condition3 passed");
		
		System.out.println("Testing condition4");
		Assertions.assertTrue(40>15);
		System.out.println("condition4 passed");
		
		System.out.println("Testing condition5");
		Assertions.assertTrue(60>15);
		System.out.println("condition4 passed");
		
	
	}

}
