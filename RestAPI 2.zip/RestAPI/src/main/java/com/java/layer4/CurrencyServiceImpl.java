package com.java.layer4;

import java.util.List;

import com.java.layer2.Currency;

public class CurrencyServiceImpl implements CurrencyService {

	
	public CurrencyServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Currency findCurrencyService(int currencyId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Currency> findAllAllCurrenciesService() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveCurrencyService(Currency currency) {
		// TODO Auto-generated method stub

	}

	@Override
	public void modifyCurrencyService(Currency currency) {
		// TODO Auto-generated method stub

	}

	@Override
	public void removeCurrencyService(int currencyId) {
		// TODO Auto-generated method stub

	}

}
