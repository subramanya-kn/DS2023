package com.ds.layer3.exceptions;

public class EmployeeNotFoundException extends Exception {

	public EmployeeNotFoundException(String msg) {
		super(msg);
	}

}
